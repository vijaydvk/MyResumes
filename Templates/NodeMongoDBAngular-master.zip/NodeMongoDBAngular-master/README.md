Single Page Application with Angular.js, Node.js and MongoDB (MongoJS Module)
=============================================================================

This code is an integration of Angular.js, Node.js and MongoDB.

Complete post can be found in -

http://www.phloxblog.in/single-page-application-angular-js-node-js-mongodb-mongojs-module/

This project is updated for Express 4 

https://github.com/piyasde/express4mongoangular

and the updated posts can be found in -

http://www.phloxblog.in/single-page-application-angular-js-node-js-mongodb-mongojs-module-updated-express-4-part-1/

http://www.phloxblog.in/single-page-application-angular-js-node-js-mongodb-mongojs-module-updated-express-4-part-2/

http://www.phloxblog.in/server-side-testing-mocha-node-js/



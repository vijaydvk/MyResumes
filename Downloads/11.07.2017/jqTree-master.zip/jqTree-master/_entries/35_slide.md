---
title: slide
name: options-slide
---

Turn slide animation on or off. Default is true.

{% highlight js %}
$('#tree1').tree({
    slide: false
});
{% endhighlight %}

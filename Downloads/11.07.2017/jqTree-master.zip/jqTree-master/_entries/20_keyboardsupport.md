---
title: keyboardSupport
name: options-keyboardsupport
---

Enable or disable keyboard support. Default is enabled.

Example: disable keyboard support.

{% highlight js %}
$('#tree1').tree({
    keyboardSupport: false
});
{% endhighlight %}

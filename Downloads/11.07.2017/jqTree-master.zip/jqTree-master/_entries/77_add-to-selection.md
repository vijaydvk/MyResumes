---
title: addToSelection
name: multiple-selection-add-to-selection
---

Add this node to the selection

{% highlight js %}
var node = $('#tree1').tree('getNodeById', 123);
$('#tree1').tree('addToSelection', node);
{% endhighlight %}

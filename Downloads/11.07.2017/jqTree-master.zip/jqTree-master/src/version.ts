const version = "1.4.2";

export default version;

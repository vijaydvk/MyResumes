require('./dist/angular-ui-tree');
module.exports = 'ui.tree';

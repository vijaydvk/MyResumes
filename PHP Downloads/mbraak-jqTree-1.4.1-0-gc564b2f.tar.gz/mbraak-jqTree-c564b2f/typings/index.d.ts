/// <reference path="globals/jquery-mockjax/index.d.ts" />
/// <reference path="globals/jquery/index.d.ts" />
/// <reference path="globals/qunit/index.d.ts" />

const $tree = $("#tree1");

$tree.tree({
    data: ExampleData.example_data
});

---
title: toJson
name: functions-tojson
---

**function toJson();**

Get the tree data as json.

{% highlight js %}
// Assuming the tree exists
$('#tree1').tree('toJson');
{% endhighlight %}

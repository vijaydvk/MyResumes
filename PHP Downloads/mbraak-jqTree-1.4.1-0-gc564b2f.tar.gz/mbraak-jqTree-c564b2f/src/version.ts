const version = "1.4.1";

export default version;

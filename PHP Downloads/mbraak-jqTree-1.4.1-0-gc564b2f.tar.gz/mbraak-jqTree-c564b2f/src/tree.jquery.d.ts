// tslint:disable-next-line: interface-name
interface JQuery {
    tree: (function_name: string, ...params: any[]) => any;
}
